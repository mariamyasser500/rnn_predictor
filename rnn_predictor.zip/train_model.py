import tensorflow as tf
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, SimpleRNN, Dense
import numpy as np
import pickle

# قراءة البيانات
with open("data.txt", "r", encoding="utf-8") as file:
    text = file.read().lower()

tokenizer = Tokenizer()
tokenizer.fit_on_texts([text])
word_index = tokenizer.word_index
total_words = len(word_index) + 1
input_seq = tokenizer.texts_to_sequences([text])[0]

seq_length = 3
sequences = []
for i in range(seq_length, len(input_seq)):
    seq = input_seq[i-seq_length:i+1]
    sequences.append(seq)

sequences = np.array(sequences)
X = sequences[:, :-1]
y = to_categorical(sequences[:, -1], num_classes=total_words)

model = Sequential()
model.add(Embedding(total_words, 50, input_length=seq_length))
model.add(SimpleRNN(100, return_sequences=False))
model.add(Dense(total_words, activation='softmax'))

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(X, y, epochs=30, verbose=1)

model.save("rnn_model.h5")
with open("tokenizer.pkl", "wb") as f:
    pickle.dump(tokenizer, f)
