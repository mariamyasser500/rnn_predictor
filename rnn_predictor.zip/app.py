from flask import Flask, request, jsonify
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np
import pickle

model = load_model("rnn_model.h5")
with open("tokenizer.pkl", "rb") as f:
    tokenizer = pickle.load(f)

app = Flask(__name__)

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    text = data.get("text", "").lower().split()

    if len(text) < 3:
        return jsonify({"error": "Please enter at least 3 words."})

    seq = tokenizer.texts_to_sequences([" ".join(text[-3:])])[0]
    seq = pad_sequences([seq], maxlen=3)
    prediction = model.predict(seq)
    word_index = np.argmax(prediction)
    predicted_word = tokenizer.index_word.get(word_index, "unknown")

    return jsonify({"word": predicted_word})

if __name__ == "__main__":
    app.run(debug=True)
